/**************************************************************************************************
		Platform: LPC2148 Development Board.
		
		This application code demostrates LCD interface on LPC2148 development board 

		Hardware Setup:-
        Insert all LCD jumpers.
        
		Clock Settings:
		FOSC	>>	12MHz (onboard)
		PLL		>>	M=5, P=2
		CCLK	>>  60MHz
		PCLK	>>  15MHz 
**************************************************************************************************/



#include  <lpc214x.h>	  //Includes LPC2148 register definitions

#define LCD_RS_HIGH() 	IO0SET = (1<<16)		 //Function to select data port on LCD
#define LCD_RS_LOW()		IO0CLR = (1<<16)		 //Function to select command port on LCD

#define LCD_RW_HIGH()		IO0SET = (1<<17)		 //Function to select read operation on LCD
#define LCD_RW_LOW()		IO0CLR = (1<<17)		 //Function to select write operation on LCD

#define LCD_EN_HIGH() 	IO0SET = (1<<18)		 //Function to Enable LCD
#define LCD_EN_LOW() 		IO0CLR = (1<<18)		 //Function to disable LCD
//                         "1234567890123456"
unsigned char String1[]={"  LCD Interface "};
unsigned char String2[]={"  Test Program  "};

void  delay_ms(unsigned char time)	   //This Function is used to cause delay between LED ON and OFF events
{  
 unsigned int  i, j;
 for (j=0; j<time; j++)
  for(i=0; i<8002; i++);
}

void LCD_Command(unsigned char command)
{
		unsigned char temp=0;
	
		LCD_RW_LOW();
	  LCD_RS_LOW();
	
		temp = (command & 0xF0) >> 4;
	  IO0CLR = 0xF <<19;			// Clear LCD Data lines
		IO0SET = temp << 19;  

		LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();

		temp = (command & 0x0F);
		IO0CLR = 0xF <<19;			// Clear LCD Data lines
		IO0SET = temp << 19;  

		LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();
	
}

void LCD_Data(unsigned char data)
{
		unsigned char temp=0;
	
		LCD_RW_LOW();
	  LCD_RS_HIGH();
	
		temp = (data & 0xF0) >> 4;
	  IO0CLR = 0xF <<19;			// Clear LCD Data lines
		IO0SET = temp << 19;  

		LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();

		temp = (data & 0x0F);
		IO0CLR = 0xF <<19;			// Clear LCD Data lines
		IO0SET = temp << 19;  

		LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();
	
}

void LCD_Init()
{
		LCD_RW_LOW();
	  LCD_RS_LOW();
	
	  IO0CLR = 0x0F <<19;			// Clear LCD Data lines
		IO0SET = 0x03 << 19;  
	
	  LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();
	
	  IO0CLR = 0x0F <<19;			// Clear LCD Data lines
		IO0SET = 0x03 << 19;  
	
	  LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();
	
	
	  IO0CLR = 0x0F <<19;			// Clear LCD Data lines
		IO0SET = 0x02 << 19;  
	
	  LCD_EN_HIGH();
		delay_ms(1);
		LCD_EN_LOW();
	
		LCD_Command(0x28);
		delay_ms(20);
		LCD_Command(0x28);
		delay_ms(20);
		LCD_Command(0x0C);
		delay_ms(20);
		LCD_Command(0x06);
		delay_ms(20);
		LCD_Command(0x01);
		delay_ms(20);
}

                               
LCD_DisplayString(unsigned char *string)
{
  while(*string)				//Check for End of String
  LCD_Data(*string++); 	//sending data on LCD byte by byte
}





int main(void)
{ 
 PINSEL0 = 0x00000000;		// Enable GPIO on all pins
 PINSEL1 = 0x00000000;
 PINSEL2 = 0x00000000;

 IO0DIR = 0x7F <<16;			// Set P0.16, P0.17, P0.18, P0.19, P0.20, P0.21, P0.22 as Output

 
 LCD_Init();

 LCD_DisplayString(String1);
 LCD_Command(0xC0);
 LCD_DisplayString(String2);
 
	while(1);	
 
}


