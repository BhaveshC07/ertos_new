
#include <LPC214x.H>                    /* LPC21xx definitions               */
#include <stdio.h>

#define CR     0x0D
#define Fosc            12000000                    
#define Fcclk           (Fosc * 5)                                 
#define Fpclk           (Fcclk / 4)             

#define  UART_BPS	9600	 //Set Baud Rate here
/*----------------------------------------------------------------------------
 *       init_serial:  Initialize Serial Interface
 *---------------------------------------------------------------------------*/
void init_serial (void) {
   unsigned int Baud16;
  PINSEL0 = 0x00000005;                 /* Enable RxD1 and TxD1              */
   U0LCR = 0x83;		            // DLAB = 1
   Baud16 = (Fpclk / 16) / UART_BPS;  
   U0DLM = Baud16>>8;//Baud16 / 256;							
   U0DLL = Baud16 & 0xff;//Baud16 % 256;						
   U0LCR = 0x03;
}

/*----------------------------------------------------------------------------
 *       sendchar:  Write a character to Serial Port
 *---------------------------------------------------------------------------*/
int fputc (int ch, FILE *f) {
  if (ch == '\n') {
    while (!(U0LSR & 0x20));
    U0THR = CR;                          /* output CR                        */
  }
  while (!(U0LSR & 0x20));
  return (U0THR = ch);
}

/*----------------------------------------------------------------------------
 *       getchar:  Read a character from Serial Port
 *---------------------------------------------------------------------------*/
int fgetc (FILE *f) {
  while (!(U0LSR & 0x01));
  return (U0RBR);
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/


