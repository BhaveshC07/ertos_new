
/**
@file
This module contais the function prototypes for the SerialPort API's.
All the functions used to communicate with the UART are declared here.
*/
#ifndef SERIAL_H_
#define SERIAL_H_

extern void uart0_init(void);

extern void init_serial (void);
extern int fputc (int ch, FILE *f);
extern int fgetc (FILE *f);
extern int is_printable(int ch);

#endif


/**
End of file

*/

